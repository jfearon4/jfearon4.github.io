# Replication code for 
# James D. Fearon, "Civil war and the current international system," 
# Daedalus, Fall 2017.

#setwd("../papers/daedalus/replication")

m = read.csv("civilwars.csv",as.is=T)
a = read.csv("civil_war_trends_data.csv",as.is=T)
pko = read.csv("pko_list.csv",as.is = T)

# VARIABLES

# data set m:  Civil war list. Updated version of list described in Fearon and Laitin (2003) and Fearon (2004).  I view this version as still somewhat "beta" (that is, I have more uncertainty about some of the codings than I would like), but here it is.  Comments welcome and appreciated.

# country
# ccode:  COW country code
# casename:  Short conflict reference.
# year:  Start year of conflict.
# endyear:  End year of conflict.  NA if not ended.
# ended:  1 if ended, 0 if not.
# impwar:  Colonial conflict (in formal colony seeking independence).
# islamist:  One or more rebel groups avow jihad.
# pko:  UN or other multilateral PKO either during or immediately following conflict.
# region

 # data set a: Rows are years from 1945 to 2014.
# year
# wars:  # of civil wars occuring in year, using dataset m.
# cns:  # of independent states in year, based on COW system membership file.
# cns.nonmicro:  # independent states in year that had population >= 500,000 in 2000, plus the following states
			   # # that do not have 2000 population data.  Cow codes: 265, 315, 341, 347, 626, 678, 680, 817, 860.
# cwars:  # non-colonial civil wars in year (impwar == 0).
# onsets:  # civil war starts in year.
# ends:  # civil war ends in year.
# avg.dur:  Average duration of civil wars in progress in year.
# med.dur:  Median duration of civil wars in progress in year.
# islamist:  # wars in year with islamist == 1.
# unpkos:  # wars in year with m$pko > 0.

  # data set pko:  Rows are UNPKO missions.
# country
# ccode:  COW country code (for civil war cases).
# mission:  PKO full name.
# mcode:  Mission abbreviation.
# styear:  Begin year of PKO.
# endyear:  End year of PKO.
# eyear:  endyear with 2015 for NA.
# mcode2:  Folds continuations into larger mission abbreviation.  


 # FIGURE AND TABLE REPLICATION CODE.

 # FIGURE 1 IN FINAL VERSION
pdf("../papers/daedalus/replication/warsperyear_no_micro.pdf",width=8)
col = 1; lty = 2  # for paper version
par(mar=c(4,4,4,4)+.1)
plot(cwars ~ year,data=a,'l',lwd=2,ylab="# of civil wars ongoing")
lines(I(40*cwars/cns.nonmicro/.25) ~ year,data=a,col=col,lwd=2,lty=lty)
c = seq(0,25,5); c2 = c*40/.25/100
axis(4,at=c2,labels=c)
mtext("% countries (non-microstates) with civil war ongoing",4,line=2,col=col)
title("Civil wars by year, 1945-2014")
legend("topleft",c('# ongoing','wars/country (no microstates)'),lty=c(1,lty),lwd=2,col=c(1,col))
graphics.off()



# FIGURE 2

pdf("../papers/daedalus/replication/warsperyear_by_region.pdf",width=11)
reg = c('subSaharan Africa','Asia','Middle East/N. Africa','L. America/Carib.','E. Eur./FSU','W. Europe/N. America')
par(mfrow=c(2,3)); k = 0
for (i in c('SSA',"Asia",'NA/ME','LA/Ca','EEur','West'))  {k = k + 1;j = m$region==i
	z = sapply(1945:2014,function(x) sum(j & m$impwar==0 & m$year <= x & replace(m$endyear,is.na(m$endyear),2014) >= x))
	plot(z ~ I(1945:2014),type="l",lwd=2,xlab="year",ylab="# civil wars ongoing",ylim=c(0,15))
	if(i=="NA/ME") {polygon(c(2001,2014,2014,2001),c(0,0,15,15),col="gray85",border=NA)
		lines(z ~ I(1945:2014),lwd=2)}
	title(reg[k])
	}
graphics.off()


 # FIGURE 3
pdf("../papers/daedalus/replication/cw_duration.pdf",width=8)
plot(avg.dur ~ year,data=a,'l',lwd=2,ylab="duration of wars in progress, in years")
lines(med.dur ~ year,data=a,lwd=2,col=1,lty=2)
legend("topleft",c('Avg. duration of civil wars ongoing in year','Median dur of wars ongoing in year'),lty=1:2,lwd=2,col=1)
title("Accumulation in system of long-running conflicts")
graphics.off()

 # FIGURE 4
pdf("../papers/daedalus/replication/islamist.pdf",width=8)
lty1 = 2; col1 = 1; lty2 = 3; col2 = 1  # for paper
plot(wars ~ year,data=a,'l',lwd=2,ylim=c(0,50)) 
lines(islamist ~ year,data=a,col=col1,lty=lty1,lwd=2)
lines(I(100*islamist/wars) ~ year,data=a,col=col2,lty=lty2,lwd=2)
legend("topleft",c('# civil wars','# with islamist aspect','% with islamist aspect'),lty=c(1,lty1,lty2),col=c(1,col1,col2),lwd=2)
title("Large growth in civil wars with significant jihadi presence")
graphics.off()

 # FIGURE 5
pdf("../papers/daedalus/replication/unpkos.pdf",width=8)
plot(cwars ~ year,data=a,'l',lwd=2,ylab="# of civil wars/UN PKOs ongoing")
lines(unpkos ~ year,data=a,col=1,lty=2,lwd=2)
#title("Civil wars and UNPKOs by year, 1945-2014")
legend("topleft",c('# civil wars ongoing','#UN PKOs ongoing'),lty=1:2,lwd=2,col=1)
graphics.off()


 # table of pko's by region
i = m$endyear > 1989 | is.na(m$endyear)
t1 = table(m$region[i],m$pko[i])
t2 = round(prop.table(table(m$region[i],m$pko[i]),1),2)
c = c(matrix(1:12,nrow=2,byrow=T))
t = rbind(t2,t1)[c,]
t = cbind(c('MENA','','Asia','','subSah. Africa','','E. Eur/former USSR','','L. Am./Carib.',''),t[1:10,][c(7,8,1,2,9,10,3,4,5,6),]) # dropping West.
colnames(t) = c('Region','No PKO','PKO')
library(xtable)
print(xtable(t),include.rownames=F)

